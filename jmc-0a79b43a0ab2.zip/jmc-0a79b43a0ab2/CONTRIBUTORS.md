#Contributors

A lot of people have been involved with Mission Control over the years. 
This document is a thank you to everyone who has ever contributed to 
Mission Control. The list may very well be incomplete - if you think you 
should be on the list, please let the project lead know!

List of contributors, approximately in order of time spent on project:

* Marcus Hirt
* Markus Persson
* Erik Gahlin
* Klara Ward
* Mattias Joëlson
* David Lindholm
* Henrik Dafgård
* Ola Westin
* Per Kroon 
* Erik Greijus
* Noora Peura
* Helena Åberg
* William Saar
* Johan Ringdahl
* Magnus Ihse
* Johan Walles
* Thomas Hallgren
* Glyn Burton
* Misha Dmitriev
* Jean-Francois Denise
* Rasmus Tehler
* Suchita Chaturvedi
* Guru Hb
* Sharath Ballal
* Peter Boström